# Growth Protocol — 7 Day Tracker

A responsive, single-file dashboard for tracking the ₹500 to ₹20,000 scenario starting 5 November 2026.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a new public GitHub repository.
2. Upload `index.html` and this `README.md`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Your site URL will appear in the Pages section.

## Included
- 7 daily milestones from 5–11 November 2026
- 3% balance compounding projection
- Period number, date, stake and outcome entry
- Win, loss and skipped-period logging
- Trade history, browser-local saving and CSV export

The projection assumes every winning trade adds a net 3% to the current balance. It is a mathematical scenario, not a guaranteed result or financial advice. Data is saved in the browser on the device where the page is opened.
